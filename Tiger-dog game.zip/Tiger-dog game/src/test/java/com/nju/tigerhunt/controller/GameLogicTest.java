package com.nju.tigerhunt.controller;

import com.nju.tigerhunt.model.Board;
import com.nju.tigerhunt.model.Dog;
import com.nju.tigerhunt.model.GameState;
import com.nju.tigerhunt.model.Position;
import com.nju.tigerhunt.model.Tiger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GameLogicTest {
    private GameController controller;
    private GameState state;
    private Board board;

    @BeforeEach
    void setUp() {
        controller = new GameController(null);
        state = controller.getState();
        board = state.getBoard();
    }

    @Test
    void dogsAlwaysMoveFirst() {
        assertEquals(GameState.Player.DOG, state.getCurrentPlayer(), "Dogs should move first.");
    }

    @Test
    void tigerMoveMustFollowNeighborConnection() {
        clearBoard();
        int tigerId = board.getPosition(2, 2).getId();
        int destinationId = board.getPosition(0, 0).getId();

        state.setPieceAt(tigerId, new Tiger());
        state.setCurrentPlayer(GameState.Player.TIGER);

        String validation = controller.makeMove(tigerId, destinationId);

        assertNotNull(validation, "Invalid tiger move should be rejected.");
        assertEquals("Pieces can only move one step along connected lines.", validation);
    }

    @Test
    void tigerCapturesTwoDogsOnlyWhenMovingIntoMiddleSpace() {
        clearBoard();

        int dogA = board.getPosition(0, 2).getId();
        int dogB = board.getPosition(2, 2).getId();
        int tigerFrom = board.getPosition(1, 1).getId();
        int target = board.getPosition(1, 2).getId();

        state.setPieceAt(dogA, new Dog());
        state.setPieceAt(dogB, new Dog());
        state.setPieceAt(tigerFrom, new Tiger());
        state.setDogsAlive(2);
        state.setCurrentPlayer(GameState.Player.TIGER);

        String result = controller.makeMove(tigerFrom, target);

        assertNull(result, "Tiger moving into capture position should succeed.");
        assertNull(state.getPieceAt(dogA), "First dog should be captured.");
        assertNull(state.getPieceAt(dogB), "Second dog should be captured.");
        assertTrue(state.getPieceAt(target) instanceof Tiger, "Tiger should land on the capture square.");
        assertEquals(0, state.getDogsAlive(), "Two dogs should be removed from the board.");
        assertTrue(state.isGameOver(), "Game should end when only two dogs remain after capture.");
        assertEquals("Tiger Victory", state.getGameMessage());
    }

    @Test
    void dogMoveThatCreatesDogTigerDogDoesNotCapture() {
        clearBoard();

        int tiger = board.getPosition(1, 2).getId();
        int movingDog = board.getPosition(1, 0).getId();
        int destination = board.getPosition(1, 1).getId();
        int otherDog = board.getPosition(1, 3).getId();

        state.setPieceAt(tiger, new Tiger());
        state.setPieceAt(movingDog, new Dog());
        state.setPieceAt(otherDog, new Dog());
        state.setDogsAlive(3);
        state.setCurrentPlayer(GameState.Player.DOG);

        String result = controller.makeMove(movingDog, destination);

        assertNull(result, "Dog move should be allowed when destination is empty.");
        assertTrue(state.getPieceAt(destination) instanceof Dog, "Dog should occupy the moved square.");
        assertTrue(state.getPieceAt(tiger) instanceof Tiger, "Tiger should remain on its square.");
        assertTrue(state.getPieceAt(otherDog) instanceof Dog, "Other dog should remain in place.");
        assertEquals(3, state.getDogsAlive(), "Dogs alive should not change when a dog moves.");
        assertFalse(state.isGameOver(), "Game should not end from a dog move.");
    }

    @Test
    void tigerLosesWhenSurroundedWithNoMoves() {
        clearBoard();

        Position tiger = board.getPosition(2, 2);
        assertNotNull(tiger);
        state.setPieceAt(tiger.getId(), new Tiger());

        for (Position neighbor : tiger.getNeighbors()) {
            state.setPieceAt(neighbor.getId(), new Dog());
        }

        Position dogToMove = board.getPosition(4, 4);
        Position dogTarget = board.getPosition(4, 3);
        assertNotNull(dogToMove);
        assertNotNull(dogTarget);
        state.setPieceAt(dogToMove.getId(), new Dog());
        state.setPieceAt(dogTarget.getId(), null);

        state.setDogsAlive(tiger.getNeighbors().size() + 1);
        state.setCurrentPlayer(GameState.Player.DOG);

        String result = controller.makeMove(dogToMove.getId(), dogTarget.getId());

        assertNull(result, "Dog move should be allowed.");
        assertTrue(state.isGameOver(), "Game should end when Tiger has no legal moves.");
        assertEquals("Dog Victory", state.getGameMessage());
    }

    @Test
    void undoRestoresPreviousState() {
        clearBoard();

        Position dogStart = board.getPosition(0, 0);
        Position dogEnd = board.getPosition(0, 1);
        assertNotNull(dogStart);
        assertNotNull(dogEnd);

        state.setPieceAt(dogStart.getId(), new Dog());
        state.setPieceAt(dogEnd.getId(), null);
        state.setDogsAlive(1);
        state.setCurrentPlayer(GameState.Player.DOG);

        String result = controller.makeMove(dogStart.getId(), dogEnd.getId());

        assertNull(result, "Dog move should be valid.");
        assertTrue(state.getPieceAt(dogEnd.getId()) instanceof Dog, "Dog should move to the target.");
        assertTrue(controller.canUndo(), "Undo should be available after a move.");

        controller.undo();
        state = controller.getState();

        assertTrue(state.getPieceAt(dogStart.getId()) instanceof Dog, "Dog should be restored to the original position.");
        assertNull(state.getPieceAt(dogEnd.getId()), "Target position should be empty after undo.");
        assertEquals(GameState.Player.DOG, state.getCurrentPlayer(), "Current player should revert after undo.");
    }

    @Test
    void dogWinsImmediatelyWhenTigerEntersTrapPosition() {
        clearBoard();

        Position mountainCenter = board.getPosition(-1, 2);
        Position trap = board.getTrapPosition();
        assertNotNull(mountainCenter);
        assertNotNull(trap);

        int from = mountainCenter.getId();
        int to = trap.getId();
        state.setPieceAt(from, new Tiger());
        state.setPieceAt(to, null);
        state.setDogsAlive(3);
        state.setCurrentPlayer(GameState.Player.TIGER);

        String result = controller.makeMove(from, to);

        assertNull(result, "Tiger move to trap should be allowed if connected.");
        assertTrue(state.isGameOver(), "Game should end when Tiger enters the trap.");
        assertEquals("Dog Victory", state.getGameMessage());
    }

    private void clearBoard() {
        for (Position position : board.getPositions()) {
            state.setPieceAt(position.getId(), null);
        }
    }
}
