package com.nju.tigerhunt.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Board {
    public static final int GRID_SIZE = 5;
    public static final int SIZE = GRID_SIZE;
    private final List<Position> positions = new ArrayList<>();
    private final Map<String, Position> positionMap = new HashMap<>();
    private final Position trap;
    private final Position mountainLeft;
    private final Position mountainCenter;
    private final Position mountainRight;

    public Board() {
        int id = 0;

        // 1. Initialize the 5x5 Grid
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                addPosition(id++, row, col);
            }
        }

        // 2. Initialize the Mountain
        mountainLeft = addPosition(id++, -1, 1);
        mountainCenter = addPosition(id++, -1, 2);
        mountainRight = addPosition(id++, -1, 3);
        trap = addPosition(id++, -2, 2);

        connectGridNeighbors();
        connectMountainSection();
    }

    private Position addPosition(int id, int row, int col) {
        Position position = new Position(id, row, col);
        positions.add(position);
        positionMap.put(key(row, col), position);
        return position;
    }

    private String key(int row, int col) {
        return row + "," + col;
    }

    private void connectGridNeighbors() {
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                Position current = getPosition(row, col);
                
                // Tiger Hunting game uses an Alquerque grid. 
                // Diagonals only exist on alternating nodes.
                boolean hasDiagonals = (row + col) % 2 == 0;

                for (int dr = -1; dr <= 1; dr++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        if (dr == 0 && dc == 0) continue;

                        int neighborRow = row + dr;
                        int neighborCol = col + dc;
                        if (neighborRow < 0 || neighborRow >= GRID_SIZE || neighborCol < 0 || neighborCol >= GRID_SIZE) {
                            continue;
                        }

                        // If the move is diagonal, check if this specific node allows it
                        if (dr != 0 && dc != 0 && !hasDiagonals) {
                            continue;
                        }

                        Position neighbor = getPosition(neighborRow, neighborCol);
                        if (neighbor != null && !current.isNeighbor(neighbor)) {
                            current.addNeighbor(neighbor);
                        }
                    }
                }
            }
        }
    }

    private void connectMountainSection() {
        // Connect Trap downward to the three mountain nodes
        connectBi(trap, mountainLeft);
        connectBi(trap, mountainCenter);
        connectBi(trap, mountainRight);

        // Connect the horizontal line across the mountain
        connectBi(mountainLeft, mountainCenter);
        connectBi(mountainCenter, mountainRight);

        // Connect all mountain nodes down to the top-center grid node (0,2).
        // This yields a single connection point at the top center as expected.
        connectBi(mountainLeft, getPosition(0, 2));   // Left mountain -> top-center
        connectBi(mountainCenter, getPosition(0, 2)); // Center mountain -> top-center
        connectBi(mountainRight, getPosition(0, 2));  // Right mountain -> top-center
    }

    private void connectBi(Position a, Position b) {
        if (a != null && b != null) {
            a.addNeighbor(b);
            b.addNeighbor(a);
        }
    }

    public static Board createDefault() {
        return new Board();
    }

    public List<Position> getPositions() {
        return Collections.unmodifiableList(positions);
    }

    public Position getPositionById(int id) {
        if (id < 0 || id >= positions.size()) {
            return null;
        }
        return positions.get(id);
    }

    public Position getPosition(int row, int col) {
        return positionMap.get(key(row, col));
    }

    public Position getTrapPosition() {
        return trap;
    }
}