package com.nju.tigerhunt.ui;

import com.nju.tigerhunt.controller.GameController;
import com.nju.tigerhunt.model.GameState;
import com.nju.tigerhunt.util.SoundPlayer;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame implements GameController.GameEventListener {
    private final GameController controller;
    private final BoardPanel boardPanel;
    private final JLabel statusLabel;
    private final JLabel timerLabel;
    private final JLabel turnLabel;
    private final JLabel undoLabel;
    private final JCheckBox showIdsCheckBox;
    private final JButton undoButton;
    private Timer timer;

    public MainFrame() {
        setTitle("Chinese Tiger Hunting Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 760);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        controller = new GameController(this);
        boardPanel = new BoardPanel(controller);
        add(boardPanel, BorderLayout.CENTER);

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(new Color(245, 239, 225));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        turnLabel = new JLabel("Turn: DOG");
        turnLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        turnLabel.setAlignmentX(LEFT_ALIGNMENT);
        rightPanel.add(turnLabel);
        rightPanel.add(Box.createVerticalStrut(12));

        timerLabel = new JLabel("Time: 00:00");
        timerLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        timerLabel.setAlignmentX(LEFT_ALIGNMENT);
        rightPanel.add(timerLabel);
        rightPanel.add(Box.createVerticalStrut(24));

        statusLabel = new JLabel("Dogs move first.", SwingConstants.LEFT);
        statusLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        statusLabel.setAlignmentX(LEFT_ALIGNMENT);
        statusLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        statusLabel.setOpaque(true);
        statusLabel.setBackground(new Color(255, 255, 255));
        statusLabel.setPreferredSize(new Dimension(240, 80));
        statusLabel.setMaximumSize(new Dimension(240, 80));
        rightPanel.add(statusLabel);
        rightPanel.add(Box.createVerticalStrut(24));

        JButton newGameButton = new JButton("New Game");
        newGameButton.setAlignmentX(LEFT_ALIGNMENT);
        newGameButton.addActionListener(e -> resetGame());
        rightPanel.add(newGameButton);
        rightPanel.add(Box.createVerticalStrut(12));

        undoButton = new JButton("Undo");
        undoButton.setAlignmentX(LEFT_ALIGNMENT);
        undoButton.addActionListener(e -> {
            if (controller.canUndo()) {
                controller.undo();
                SoundPlayer.playUndoSound();
            } else {
                JOptionPane.showMessageDialog(this, "Nothing to undo.", "Undo", JOptionPane.INFORMATION_MESSAGE);
            }
            updateUndoStatus();
        });
        rightPanel.add(undoButton);
        rightPanel.add(Box.createVerticalStrut(8));

        undoLabel = new JLabel("Undo available: 0");
        undoLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        undoLabel.setAlignmentX(LEFT_ALIGNMENT);
        rightPanel.add(undoLabel);
        rightPanel.add(Box.createVerticalStrut(12));

        showIdsCheckBox = new JCheckBox("Show position IDs");
        showIdsCheckBox.setAlignmentX(LEFT_ALIGNMENT);
        showIdsCheckBox.addActionListener(e -> {
            boardPanel.setShowPositionIds(showIdsCheckBox.isSelected());
        });
        rightPanel.add(showIdsCheckBox);
        rightPanel.add(Box.createVerticalStrut(12));

        JButton exitButton = new JButton("Exit");
        exitButton.setAlignmentX(LEFT_ALIGNMENT);
        exitButton.addActionListener(e -> System.exit(0));
        rightPanel.add(exitButton);

        add(rightPanel, BorderLayout.EAST);

        startTimer();
        updateState(controller.getState());
        updateUndoStatus();
    }

    private void startTimer() {
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.increaseElapsedTime();
            }
        });
        timer.start();
    }

    private void resetGame() {
        controller.reset();
        timerLabel.setText("Time: 00:00");
        SoundPlayer.playResetSound();
    }

    @Override
    public void onStateChanged(GameState state) {
        updateState(state);
    }

    @Override
    public void onGameOver(String message) {
        SoundPlayer.playVictorySound();
        JOptionPane.showMessageDialog(this, message, "Game Over", JOptionPane.INFORMATION_MESSAGE);
    }

    private void updateState(GameState state) {
        boardPanel.updateState(state);
        turnLabel.setText("Turn: " + state.getCurrentPlayer());
        statusLabel.setText(String.format("<html><body style='width:200px;'>%s</body></html>", state.getGameMessage()));
        int seconds = state.getElapsedSeconds();
        timerLabel.setText(String.format("Time: %02d:%02d", seconds / 60, seconds % 60));
        updateUndoStatus();
    }

    private void updateUndoStatus() {
        undoButton.setEnabled(controller.canUndo());
        undoLabel.setText("Undo available: " + controller.getUndoCount());
    }
}
