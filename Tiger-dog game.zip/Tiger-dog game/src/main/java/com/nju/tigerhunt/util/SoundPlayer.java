package com.nju.tigerhunt.util;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.awt.Toolkit;
import java.io.IOException;
import java.net.URL;

public class SoundPlayer {
    public static void playMoveSound() {
        playSound("move.wav");
    }

    public static void playUndoSound() {
        playSound("undo.wav");
    }

    public static void playVictorySound() {
        playSound("victory.wav");
    }

    public static void playResetSound() {
        playSound("reset.wav");
    }

    public static void playErrorSound() {
        playSound("error.wav");
    }

    private static void playSound(String filename) {
        URL resource = SoundPlayer.class.getResource("/sounds/" + filename);
        if (resource == null) {
            Toolkit.getDefaultToolkit().beep();
            return;
        }

        try (AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(resource)) {
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (Exception e) {
            Toolkit.getDefaultToolkit().beep();
        }
    }
}
