package com.nju.tigerhunt.model;

public class Dog extends Piece {
    @Override
    public String getName() {
        return "Dog";
    }

    @Override
    public String getSymbol() {
        return "D";
    }
}
