package com.nju.tigerhunt.controller;

import com.nju.tigerhunt.model.Board;
import com.nju.tigerhunt.model.Dog;
import com.nju.tigerhunt.model.GameState;
import com.nju.tigerhunt.model.Move;
import com.nju.tigerhunt.model.Piece;
import com.nju.tigerhunt.model.Position;
import com.nju.tigerhunt.model.Tiger;

import java.util.ArrayList;
import java.util.List;

public class GameController {
    private final List<GameState> history = new ArrayList<>();
    private final Board board;
    private GameState state;
    private GameEventListener listener;

    public GameController(GameEventListener listener) {
        this.board = Board.createDefault();
        this.listener = listener;
        this.state = new GameState(board);
        pushHistory();
    }

    public GameState getState() {
        return state;
    }

    public void reset() {
        this.state = new GameState(board);
        this.history.clear();
        pushHistory();
        notifyStateUpdated();
    }

    public String validateMove(int fromId, int toId) {
        if (state.isGameOver()) {
            return "The game has ended.";
        }
        Piece piece = state.getPieceAt(fromId);
        if (piece == null) {
            return "No piece is selected.";
        }
        Piece destination = state.getPieceAt(toId);
        if (destination != null) {
            return "Destination is not empty.";
        }
        Position from = board.getPositionById(fromId);
        Position to = board.getPositionById(toId);
        if (from == null || to == null || !from.isNeighbor(to)) {
            return "Pieces can only move one step along connected lines.";
        }
        if (state.getCurrentPlayer() == GameState.Player.DOG && !(piece instanceof Dog)) {
            return "It is Dog turn, please move a Dog.";
        }
        if (state.getCurrentPlayer() == GameState.Player.TIGER && !(piece instanceof Tiger)) {
            return "It is Tiger turn, please move the Tiger.";
        }
        return null;
    }

    public String makeMove(int fromId, int toId) {
        String validation = validateMove(fromId, toId);
        if (validation != null) {
            return validation;
        }

        pushHistory();
        Piece movingPiece = state.getPieceAt(fromId);
        state.setPieceAt(fromId, null);
        state.setPieceAt(toId, movingPiece);
        Move move = new Move(fromId, toId);
        boolean captured = false;

        if (movingPiece instanceof Tiger) {
            List<Integer> capturedDogs = captureDogs(toId);
            for (Integer dogId : capturedDogs) {
                state.setPieceAt(dogId, null);
                move.addCapturedDog(dogId);
            }
            if (!capturedDogs.isEmpty()) {
                captured = true;
                state.setDogsAlive(state.getDogsAlive() - capturedDogs.size());
            }
        }

        state.setCurrentPlayer(state.getCurrentPlayer() == GameState.Player.DOG ? GameState.Player.TIGER : GameState.Player.DOG);
        state.setGameMessage("" + state.getCurrentPlayer() + " turn.");

        if (checkVictory()) {
            state.setGameOver(true);
        }

        notifyStateUpdated();
        return null;
    }

    private void pushHistory() {
        history.add(state.copy());
        if (history.size() > 32) {
            history.remove(0);
        }
    }

    public boolean canUndo() {
        return history.size() > 1;
    }

    public int getUndoCount() {
        return Math.max(0, history.size() - 1);
    }

    public void undo() {
        if (canUndo()) {
            GameState previous = history.remove(history.size() - 1);
            state = previous.copy();
            state.setGameOver(false);
            state.setGameMessage("Undo completed. " + state.getCurrentPlayer() + " turn.");
            notifyStateUpdated();
        }
    }

    private boolean checkVictory() {
        if (state.getDogsAlive() <= 2) {
            state.setGameMessage("Tiger Victory");
            return true;
        }
        // Dogs win immediately if the Tiger is in the trap position at the top of the board.
        int tigerPos = findTigerPosition();
        Position trap = board.getTrapPosition();
        if (trap != null && tigerPos == trap.getId()) {
            state.setGameMessage("Dog Victory");
            return true;
        }
        if (!hasAnyTigerMoves()) {
            state.setGameMessage("Dog Victory");
            return true;
        }
        return false;
    }

    private boolean hasAnyTigerMoves() {
        int tigerPosition = findTigerPosition();
        if (tigerPosition < 0) {
            return false;
        }
        Position position = board.getPositionById(tigerPosition);
        for (Position neighbor : position.getNeighbors()) {
            if (state.getPieceAt(neighbor.getId()) == null) {
                return true;
            }
        }
        return false;
    }

    private int findTigerPosition() {
        for (Position position : board.getPositions()) {
            Piece piece = state.getPieceAt(position.getId());
            if (piece instanceof Tiger) {
                return position.getId();
            }
        }
        return -1;
    }

    private List<Integer> captureDogs(int targetId) {
        Position target = board.getPositionById(targetId);
        if (target == null) {
            return new ArrayList<>();
        }
        
        List<Integer> captured = new ArrayList<>();
        int targetRow = target.getRow();
        int targetCol = target.getCol();
        
        // Check all 8 directions (4 straight + 4 diagonal)
        for (int dr = -1; dr <= 1; dr++) {
            for (int dc = -1; dc <= 1; dc++) {
                if (dr == 0 && dc == 0) {
                    continue; // Skip center
                }
                
                // Check if dog exists one step away in direction (dr, dc)
                Position posA = board.getPosition(targetRow + dr, targetCol + dc);
                if (posA == null || !target.isNeighbor(posA)) {
                    continue;
                }
                
                Piece dogA = state.getPieceAt(posA.getId());
                if (!(dogA instanceof Dog)) {
                    continue; // No dog at this position
                }
                
                // Check if dog exists one step away in opposite direction (-dr, -dc)
                Position posB = board.getPosition(targetRow - dr, targetCol - dc);
                if (posB == null || !target.isNeighbor(posB)) {
                    continue;
                }
                
                Piece dogB = state.getPieceAt(posB.getId());
                if (!(dogB instanceof Dog)) {
                    continue; // No dog at opposite position
                }
                
                // Verify they are collinear (on same line)
                if (!target.isCollinearWith(posA, posB)) {
                    continue;
                }
                
                // Verify they are on opposite sides (not same side)
                int dx1 = posA.getCol() - targetCol;
                int dy1 = posA.getRow() - targetRow;
                int dx2 = posB.getCol() - targetCol;
                int dy2 = posB.getRow() - targetRow;
                
                // Dot product < 0 means opposite directions
                if (dx1 * dx2 + dy1 * dy2 >= 0) {
                    continue;
                }
                
                // Found a valid pair: Dog-Tiger-Dog on same line
                // Capture both dogs
                if (!captured.contains(posA.getId())) {
                    captured.add(posA.getId());
                }
                if (!captured.contains(posB.getId())) {
                    captured.add(posB.getId());
                }
            }
        }
        
        return captured;
    }

    public void increaseElapsedTime() {
        if (!state.isGameOver()) {
            state.setElapsedSeconds(state.getElapsedSeconds() + 1);
            notifyStateUpdated();
        }
    }

    private void notifyStateUpdated() {
        if (listener != null) {
            listener.onStateChanged(state);
            if (state.isGameOver()) {
                listener.onGameOver(state.getGameMessage());
            }
        }
    }

    public interface GameEventListener {
        void onStateChanged(GameState state);

        void onGameOver(String message);
    }
}
