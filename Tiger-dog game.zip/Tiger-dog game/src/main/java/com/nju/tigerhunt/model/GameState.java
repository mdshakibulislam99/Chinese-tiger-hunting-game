package com.nju.tigerhunt.model;

import java.util.Arrays;

public class GameState {
    public enum Player {
        DOG,
        TIGER
    }

    private final Board board;
    private final Piece[] positions;
    private Player currentPlayer;
    private int dogsAlive;
    private int elapsedSeconds;
    private boolean gameOver;
    private String gameMessage;

    public GameState(Board board) {
        this.board = board;
        this.positions = new Piece[board.getPositions().size()];
        initializePieces();
        this.currentPlayer = Player.DOG;
        this.dogsAlive = 16;
        this.elapsedSeconds = 0;
        this.gameOver = false;
        this.gameMessage = "Dogs move first.";
    }

    private GameState(Board board, Piece[] positions, Player currentPlayer, int dogsAlive, int elapsedSeconds, boolean gameOver, String gameMessage) {
        this.board = board;
        this.positions = positions;
        this.currentPlayer = currentPlayer;
        this.dogsAlive = dogsAlive;
        this.elapsedSeconds = elapsedSeconds;
        this.gameOver = gameOver;
        this.gameMessage = gameMessage;
    }

    private void initializePieces() {
        for (int i = 0; i < positions.length; i++) {
            positions[i] = null;
        }

        Position tigerPosition = board.getPosition(2, 2);
        if (tigerPosition != null) {
            positions[tigerPosition.getId()] = new Tiger();
        }

        int[][] dogLocations = {
            { 0, 0 },
            { 1, 0 },
            { 2, 0 },
            { 3, 0 },
            { 0, 1 },
            { 0, 2 },
            { 0, 3 },
            { 0, 4 },
            { 4, 0 },
            { 4, 1 },
            { 4, 2 },
            { 4, 3 },
            { 4, 4 },
            { 1, 4 },
            { 2, 4 },
            { 3, 4 }
        };

        for (int[] location : dogLocations) {
            Position position = board.getPosition(location[0], location[1]);
            if (position != null && positions[position.getId()] == null) {
                positions[position.getId()] = new Dog();
            }
        }
    }

    public Board getBoard() {
        return board;
    }

    public Piece getPieceAt(int positionId) {
        if (positionId < 0 || positionId >= positions.length) {
            return null;
        }
        return positions[positionId];
    }

    public void setPieceAt(int positionId, Piece piece) {
        if (positionId < 0 || positionId >= positions.length) {
            return;
        }
        positions[positionId] = piece;
    }

    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    public void setCurrentPlayer(Player currentPlayer) {
        this.currentPlayer = currentPlayer;
    }

    public int getDogsAlive() {
        return dogsAlive;
    }

    public void setDogsAlive(int dogsAlive) {
        this.dogsAlive = dogsAlive;
    }

    public int getElapsedSeconds() {
        return elapsedSeconds;
    }

    public void setElapsedSeconds(int elapsedSeconds) {
        this.elapsedSeconds = elapsedSeconds;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    public String getGameMessage() {
        return gameMessage;
    }

    public void setGameMessage(String gameMessage) {
        this.gameMessage = gameMessage;
    }

    public GameState copy() {
        Piece[] clonePieces = new Piece[positions.length];
        for (int i = 0; i < positions.length; i++) {
            Piece piece = positions[i];
            if (piece instanceof Tiger) {
                clonePieces[i] = new Tiger();
            } else if (piece instanceof Dog) {
                clonePieces[i] = new Dog();
            } else {
                clonePieces[i] = null;
            }
        }
        return new GameState(board, clonePieces, currentPlayer, dogsAlive, elapsedSeconds, gameOver, gameMessage);
    }

    public Piece[] getPositionsSnapshot() {
        return Arrays.copyOf(positions, positions.length);
    }
}
