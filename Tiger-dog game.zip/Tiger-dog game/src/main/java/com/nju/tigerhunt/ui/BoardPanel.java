package com.nju.tigerhunt.ui;

import com.nju.tigerhunt.controller.GameController;
import com.nju.tigerhunt.model.Board;
import com.nju.tigerhunt.model.Dog;
import com.nju.tigerhunt.model.GameState;
import com.nju.tigerhunt.model.Piece;
import com.nju.tigerhunt.model.Position;
import com.nju.tigerhunt.model.Tiger;
import com.nju.tigerhunt.util.SoundPlayer;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class BoardPanel extends JPanel {
    private final GameController controller;
    private GameState state;
    private Position selectedPosition;
    private final Set<Integer> availableMoves = new HashSet<>();
    private final Map<Integer, Point> coordinates = new HashMap<>();
    private final int nodeRadius = 18;
    private boolean showPositionIds = false;

    public BoardPanel(GameController controller) {
        this.controller = controller;
        setPreferredSize(new Dimension(700, 700));
        setBackground(new Color(250, 240, 220));
        setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleClick(e.getPoint());
            }
        });
    }

    public void updateState(GameState state) {
        this.state = state;
        repaint();
    }

    private void handleClick(Point clickPoint) {
        if (state == null || state.isGameOver()) {
            return;
        }
        Board board = state.getBoard();
        int clickedId = findClosestPositionId(clickPoint);
        if (clickedId < 0) {
            return;
        }
        Piece clickedPiece = state.getPieceAt(clickedId);

        if (selectedPosition != null && state.getPieceAt(selectedPosition.getId()) != null) {
            if (clickedId == selectedPosition.getId()) {
                selectedPosition = null;
                availableMoves.clear();
                repaint();
                return;
            }
            if (clickedPiece == null) {
                String result = controller.makeMove(selectedPosition.getId(), clickedId);
                if (result == null) {
                    SoundPlayer.playMoveSound();
                } else {
                    SoundPlayer.playErrorSound();
                }
                selectedPosition = null;
                availableMoves.clear();
                repaint();
                return;
            }
        }

        if (clickedPiece != null && isSelectable(clickedId)) {
            selectedPosition = board.getPositionById(clickedId);
            computeAvailableMoves(clickedId);
            repaint();
        }
    }

    private void computeAvailableMoves(int positionId) {
        availableMoves.clear();
        if (state == null) return;
        Position pos = state.getBoard().getPositionById(positionId);
        if (pos == null) return;
        for (Position neighbor : pos.getNeighbors()) {
            if (state.getPieceAt(neighbor.getId()) == null) {
                availableMoves.add(neighbor.getId());
            }
        }
    }

    private boolean isSelectable(int positionId) {
        Piece piece = state.getPieceAt(positionId);
        if (piece == null) {
            return false;
        }
        if (state.getCurrentPlayer() == GameState.Player.DOG && piece instanceof Dog) {
            return true;
        }
        return state.getCurrentPlayer() == GameState.Player.TIGER && piece instanceof Tiger;
    }

    private int findClosestPositionId(Point point) {
        int pickRadius = nodeRadius + 8;
        int found = -1;
        double bestDistance = Double.MAX_VALUE;

        for (Map.Entry<Integer, Point> entry : coordinates.entrySet()) {
            Point positionPoint = entry.getValue();
            double distance = positionPoint.distance(point);
            if (distance <= pickRadius && distance < bestDistance) {
                found = entry.getKey();
                bestDistance = distance;
            }
        }

        return found;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (state == null) {
            return;
        }
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Board board = state.getBoard();
        int width = getWidth();
        int height = getHeight();
        int padding = 60;

        int minRow = Integer.MAX_VALUE;
        int maxRow = Integer.MIN_VALUE;
        int minCol = Integer.MAX_VALUE;
        int maxCol = Integer.MIN_VALUE;
        for (Position position : board.getPositions()) {
            minRow = Math.min(minRow, position.getRow());
            maxRow = Math.max(maxRow, position.getRow());
            minCol = Math.min(minCol, position.getCol());
            maxCol = Math.max(maxCol, position.getCol());
        }

        int rowCount = maxRow - minRow;
        int colCount = maxCol - minCol;
        int cellWidth = (width - padding * 2) / colCount;
        int cellHeight = (height - padding * 2) / rowCount;

        coordinates.clear();
        for (Position position : board.getPositions()) {
            int x = padding + (position.getCol() - minCol) * cellWidth;
            int y = padding + (position.getRow() - minRow) * cellHeight;
            coordinates.put(position.getId(), new Point(x, y));
        }

        g2.setColor(new Color(115, 80, 40));
        g2.setStroke(new BasicStroke(3f));
        for (Position position : board.getPositions()) {
            Point point = coordinates.get(position.getId());
            for (Position neighbor : position.getNeighbors()) {
                if (neighbor.getId() > position.getId()) {
                    Point neighborPoint = coordinates.get(neighbor.getId());
                    g2.draw(new Line2D.Float(point.x, point.y, neighborPoint.x, neighborPoint.y));
                }
            }
        }

        g2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        g2.setColor(new Color(200, 180, 150));
        g2.fillRect(10, 10, 220, 72);
        g2.setColor(Color.DARK_GRAY);
        g2.drawRect(10, 10, 220, 72);
        g2.drawString("Tiger Hunting Game", 20, 32);
        g2.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        g2.drawString("Dogs alive: " + state.getDogsAlive(), 20, 52);
        g2.drawString("Turn: " + state.getCurrentPlayer(), 20, 68);

        for (Position position : board.getPositions()) {
            Point point = coordinates.get(position.getId());
            Piece piece = state.getPieceAt(position.getId());
            // highlight available move targets
            if (availableMoves.contains(position.getId())) {
                g2.setColor(new Color(144, 238, 144, 160));
                g2.fill(new Ellipse2D.Double(point.x - nodeRadius - 6, point.y - nodeRadius - 6, (nodeRadius + 6) * 2, (nodeRadius + 6) * 2));
            }
            Color fill = new Color(240, 230, 200);
            if (selectedPosition != null && selectedPosition.getId() == position.getId()) {
                fill = new Color(170, 210, 255);
            }
            g2.setColor(fill);
            g2.fill(new Ellipse2D.Double(point.x - nodeRadius, point.y - nodeRadius, nodeRadius * 2, nodeRadius * 2));
            g2.setColor(Color.DARK_GRAY);
            g2.setStroke(new BasicStroke(2f));
            g2.draw(new Ellipse2D.Double(point.x - nodeRadius, point.y - nodeRadius, nodeRadius * 2, nodeRadius * 2));

            if (showPositionIds) {
                g2.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));
                g2.setColor(new Color(80, 80, 80, 150));
                String idLabel = String.valueOf(position.getId());
                int idX = point.x - g2.getFontMetrics().stringWidth(idLabel) / 2;
                int idY = point.y + nodeRadius + 10;
                g2.drawString(idLabel, idX, idY);
            }

            if (piece != null) {
                if (piece instanceof Dog) {
                    g2.setColor(new Color(14, 90, 176));
                } else {
                    g2.setColor(new Color(190, 90, 5));
                }
                g2.fill(new Ellipse2D.Double(point.x - nodeRadius + 4, point.y - nodeRadius + 4, (nodeRadius - 4) * 2, (nodeRadius - 4) * 2));
                g2.setColor(Color.WHITE);
                g2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
                String label = piece instanceof Dog ? "D" : "T";
                int labelX = point.x - g2.getFontMetrics().stringWidth(label) / 2;
                int labelY = point.y + g2.getFontMetrics().getAscent() / 2 - 2;
                g2.drawString(label, labelX, labelY);
            }
        }

        if (state.isGameOver()) {
            g2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 30));
            g2.setColor(new Color(220, 20, 20, 200));
            String text = state.getGameMessage();
            int textWidth = g2.getFontMetrics().stringWidth(text);
            g2.drawString(text, (width - textWidth) / 2, height / 2);
        }

        g2.dispose();
    }

    public void setShowPositionIds(boolean showPositionIds) {
        this.showPositionIds = showPositionIds;
        repaint();
    }
}
