package com.nju.tigerhunt.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class Position {
    private final int id;
    private final int row;
    private final int col;
    private final List<Position> neighbors = new ArrayList<>();

    public Position(int id, int row, int col) {
        this.id = id;
        this.row = row;
        this.col = col;
    }

    public int getId() {
        return id;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public void addNeighbor(Position neighbor) {
        if (!neighbors.contains(neighbor)) {
            neighbors.add(neighbor);
        }
    }

    public List<Position> getNeighbors() {
        return Collections.unmodifiableList(neighbors);
    }

    public boolean isNeighbor(Position other) {
        return neighbors.contains(other);
    }

    public int distanceTo(Position other) {
        int dr = other.row - row;
        int dc = other.col - col;
        return Math.max(Math.abs(dr), Math.abs(dc));
    }

    public boolean isCollinearWith(Position a, Position b) {
        int dx1 = a.col - col;
        int dy1 = a.row - row;
        int dx2 = b.col - col;
        int dy2 = b.row - row;
        return dx1 * dy2 == dy1 * dx2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Position)) return false;
        Position position = (Position) o;
        return id == position.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
