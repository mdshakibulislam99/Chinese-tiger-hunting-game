package com.nju.tigerhunt.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Move {
    private final int fromId;
    private final int toId;
    private final List<Integer> capturedDogIds = new ArrayList<>();

    public Move(int fromId, int toId) {
        this.fromId = fromId;
        this.toId = toId;
    }

    public int getFromId() {
        return fromId;
    }

    public int getToId() {
        return toId;
    }

    public void addCapturedDog(int dogId) {
        capturedDogIds.add(dogId);
    }

    public List<Integer> getCapturedDogIds() {
        return Collections.unmodifiableList(capturedDogIds);
    }
}
