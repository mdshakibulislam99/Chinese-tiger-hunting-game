package com.nju.tigerhunt.model;

public abstract class Piece {
    public abstract String getName();
    public abstract String getSymbol();
}
