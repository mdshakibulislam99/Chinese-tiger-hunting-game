package com.nju.tigerhunt.model;

public class Tiger extends Piece {
    @Override
    public String getName() {
        return "Tiger";
    }

    @Override
    public String getSymbol() {
        return "T";
    }
}
