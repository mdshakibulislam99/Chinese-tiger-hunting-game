# Chinese Tiger Hunting Game

A Java Swing implementation of a single-machine Tiger vs Dog hunting board game.

## Features

- 5x5 board with one Tiger and sixteen Dogs
- Mouse-driven piece selection and move execution
- Dogs move first, then Tiger
- Tiger can capture a pair of Dogs by moving into the gap between them
- Dogs win by trapping the Tiger or leaving it with no legal moves
- Tiger wins when only two Dogs remain
- Game timer and undo support
- Simple sound and animation effects

## Run

Using Gradle:

```bash
gradle run
```

Or compile directly:

```bash
javac -d out src/main/java/com/nju/tigerhunt/**/*.java
java -cp out com.nju.tigerhunt.Main
```

## Structure

- `src/main/java` – Java source files
- `build.gradle` – Gradle build configuration
- `settings.gradle` – Gradle project name

## Notes

The game is designed as a local two-player desktop application. There is no AI opponent.
